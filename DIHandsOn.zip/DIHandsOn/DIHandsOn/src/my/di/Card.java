package my.di;

public interface Card {

	public void details();

}
