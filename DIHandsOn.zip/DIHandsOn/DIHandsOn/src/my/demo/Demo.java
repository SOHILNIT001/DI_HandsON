package my.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import my.di.Card;

public class Demo {

	public static void main(String[] args) {
		// DebitCard card = new DebitCard();
		// Card card = new DebitCard();
		// card.details();

		ApplicationContext ctn = new ClassPathXmlApplicationContext("application_context.xml");
		
		Card card1 = (Card) ctn.getBean("ccard");
		card1.details();
		
		Card card2 = (Card) ctn.getBean("dcard");
		card2.details();
		
		((AbstractApplicationContext)ctn).close();
	}
}
